require "test_helper"

class EdgeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
