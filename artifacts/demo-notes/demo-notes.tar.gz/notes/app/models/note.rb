class Note < ApplicationRecord
  validates :title, presence: true
  validates :body, presence: true

  scope :search, ->(query) {
    where("title LIKE ?", "%#{query}%") if query.present?
  }

  scope :recent, -> { order(updated_at: :desc) }
end
