# Sample notes for the demo
return if Note.count > 0

Note.create!(
  title: "Welcome to Notes",
  body: "This is a demo of Ruby2JS path helper RPC. The same source code runs on browser (Dexie/IndexedDB) and server (SQLite/Postgres) targets."
)

Note.create!(
  title: "Path Helper Methods",
  body: "Path helpers now have HTTP methods: notes_path.get(), notes_path.post(note: {...}), note_path(id).patch(note: {...}), note_path(id).delete()"
)

Note.create!(
  title: "Search Support",
  body: "Use query parameters: notes_path.get(q: 'search term') - parameters become query string for GET requests."
)

Note.create!(
  title: "JSON by Default",
  body: "Path helper methods default to JSON format, which is most common for React components. Use format: :html for explicit HTML."
)

puts "Created #{Note.count} notes"
